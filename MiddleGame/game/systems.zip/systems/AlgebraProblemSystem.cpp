#pragma once
#include "game_state.h"
#include "middle_system_registrar.h"
#include "middle_shape_utils.h"
#include "MidComp/MouseClickComponent.h"
#include "MidComp/Button.h"
#include "bubble_actions.h"
#include "bubble_utils.h"
#include "MidComp/Rectangle.h"
#include "MidComp/CameraComponent.h"
#include "MidComp/ProcedureContainer.h"
#include "bubble_constants.h"
#include "editor_file_utils.h"
#include "MidComp/GlobalTransform.h"
#include "equlab_actions.h"

class AlgebraProblemSystem : public middle::MiddleGameplaySystem {
public:


	void init(middle::GameState* gameState) {
	}

	void undo(middle::GameState* gameState) {
		if (gameState->bubbleAlgebraState.bubbleActions.size() > 0) {
			auto action = std::make_shared<equlab::UndoAction>();
			middle::queueAction(gameState, action);
		}
	}

	void update(middle::GameState* gameState) override {

		if (gameState->bubbleAlgebraState.postUndoFrames > 0) {
			--gameState->bubbleAlgebraState.postUndoFrames;
		}

		if (gameState->middleInputState.gameInput.undo) {
			undo(gameState);
		}


	}

};

static middle::SystemRegistrar<AlgebraProblemSystem> reg("AlgebraProblemSystem");
