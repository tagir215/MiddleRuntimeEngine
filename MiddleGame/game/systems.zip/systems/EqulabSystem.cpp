#pragma once
#include "game_state.h"
#include "middle_system_registrar.h"
#include "middle_shape_utils.h"
#include "equlab_actions.h"
#include "MidComp/BubbleComponent.h"
#include "MidComp/SelectedComponent.h"
#include "component_utils.h"
#include "MidComp/BubbleUnit.h"
#include "alg_file_utils.h"
#include "MidComp/LoopSociety.h"
#include "MidComp/BubbleEqualsComponent.h"
#include "MidComp/BubbleVariable.h"
#include "MidComp/TimerComponent.h"
#include "MidComp/TopDogBubbleTag.h"
#include "bubble_paths.h"
#include "MidComp/ActiveSceneEditableTag.h"
#include "MidComp/IntersectingTag.h"
#include "bubequ_mapping.h"
#include "MidComp/BubbleGateComponent.h"
#include "MidComp/NonPhysicalBubbleTag.h"
#include "midconfig.h"
#include "abstract_ui.h"

class EqulabSystem : public middle::MiddleGameplaySystem {
public:

	enum class SelectType {
		NONE,
		ADD_MULTIPLICATION,
		ADD_POWER
	};

	SelectType currentSelectType = SelectType::NONE;

	components::CompCache* intersectableBubbleCache;
	components::CompCache* intersectableUnitCache;
	components::CompCache* selectedCache;
	components::CompCache* timerCache;
	components::CompCache* activeBubbleCache;

	void init(middle::GameState* gameState) override {
		intersectableBubbleCache = middle::newCompCache(gameState, systemName);
		intersectableBubbleCache->addType<components::IntersectingTag>();
		intersectableBubbleCache->addType<components::BubbleComponent>();
		intersectableBubbleCache->addType<components::NonPhysicalBubbleTag>(components::NOTINTERESTED);

		intersectableUnitCache = middle::newCompCache(gameState, systemName);
		intersectableUnitCache->addType<components::IntersectingTag>();
		intersectableUnitCache->addType<components::BubbleUnit>();
		intersectableUnitCache->addType<components::NonPhysicalBubbleTag>(components::NOTINTERESTED);

		selectedCache = middle::newCompCache(gameState, systemName);
		selectedCache->addType<components::SelectedComponent>();
		selectedCache->addType<components::BubbleComponent>();

		timerCache = middle::newCompCache(gameState, systemName);
		timerCache->addType<components::TimerComponent>();
		timerCache->addType<components::BubbleComponent>();

		activeBubbleCache = middle::newCompCache(gameState, systemName);
		activeBubbleCache->addType<components::ActiveSceneSelectableTag>();
	}

	std::string keyToString(middle::GameState* gameState) {
		auto& in = gameState->middleInputState.equlabInput;
		if (in.aClicked) return "a";
		if (in.bClicked) return "b";
		if (in.cClicked) return "c";
		if (in.dClicked) return "d";
		if (in.eClicked) return "e";
		if (in.fClicked) return "f";
		if (in.gClicked) return "g";
		if (in.hClicked) return "h";
		if (in.iClicked) return "i";
		if (in.jClicked) return "j";
		if (in.kClicked) return "k";
		if (in.lClicked) return "l";
		if (in.mClicked) return "m";
		if (in.nClicked) return "n";
		if (in.oClicked) return "o";
		if (in.pClicked) return "p";
		if (in.qClicked) return "q";
		if (in.rClicked) return "r";
		if (in.sClicked) return "s";
		if (in.tClicked) return "t";
		if (in.uClicked) return "u";
		if (in.vClicked) return "v";
		if (in.wClicked) return "w";
		if (in.xClicked) return "x";
		if (in.yClicked) return "y";
		if (in.zClicked) return "z";
		return "";
	}

	std::vector<bool>fileButtons;

	void update(middle::GameState* gameState) override {

		// SAVING 
		using namespace middleUI;

		START_MIDGUI(gameState);
		midguiBegin("Bubequ file");

		//midguiInput("Equation name");

		static char equationName[128] = "TODO NAME";
		//ui.midgui(InputText); ui.label("Equation name"); ui.string(equationName); ui.setSize(IM_ARRAYSIZE(equationName));

		if (midguiIsItemFocused()) {
			middle::insertInputBlock(gameState, middle::InputBlockers::KEYBOARD_BLOCK);
			middle::insertInputBlock(gameState, middle::InputBlockers::MOUSE_BLOCK);
		}

		if (midguiButton("save")) {
			for (middle::Id& activeId : activeBubbleCache->relevantIdVector) {
				std::string name = equationName;
				std::shared_ptr<bubequ::Scope> root;
				if (gameState->bubbleAlgebraState.activeBubbleName != "") {
					name = gameState->bubbleAlgebraState.activeBubbleName;
					middle::Id backgroundId = gameState->bubbleAlgebraState.backgroundBubbleId;
					auto newBranch = bubequ::bubbleToBubequ(gameState, backgroundId);
					root = bubequ::loadBubequHead(name, {}, gameState->bubbleAlgebraState.loadDepth);
					// load root from disc
					// replace current visible branch on the loaded tree
					bubequ::replaceBranch(root, newBranch, gameState->bubbleAlgebraState.traversePath);
				}
				else {
					root = bubequ::bubbleToBubequ(gameState, activeId);
				}

				// convert to hashes and save head reference
				std::unordered_map<std::string, std::string>hashMap;
				std::string head = bubequ::bubequToHashes(gameState, root, hashMap);
				bubequ::saveBubequHead(equationName, head, hashMap, gameState->bubbleAlgebraState.traversePath, { 0,0,0 }, 1);
			}
		}

		midguiEnd();

		// UI 

		// BUBEQU LIST
		midguiBegin("bubequ list");

		static std::vector<std::string>filenames = bubequ::getFilenames(std::string(bubblePaths::EQUATION_FOLDER));

		if (fileButtons.size() != filenames.size()) {
			fileButtons = std::vector<bool>(filenames.size(), false);
		}
		for (int i = 0; i < filenames.size(); ++i) {
			auto& name = filenames[i];

			if (midguiButton(name.c_str())) {
				const std::string path = std::string(bubblePaths::EQUATION_FOLDER) + "/" + name + ".bubequ";
				midMath::Vector3 camXZPos = middle::getActiveCam(gameState).position;
				camXZPos.y = 0;
				//auto bubequ = bubequ::loadBubequ(path);

				auto bubequ = bubequ::loadBubequHead(name, {}, gameState->bubbleAlgebraState.loadDepth);

				middle::Id id = bubequ::bubequToBubble(gameState, camXZPos, bubequ);
				auto registerAction = std::make_shared<middle::EditorActionRegisterId>(id);
				middle::queueAction(gameState, registerAction);
				gameState->bubbleAlgebraState.bubbleActions.push_back(registerAction);

				// todo change
				gameState->bubbleAlgebraState.activeBubbleName = name;
			}
		}

		midguiEnd();

		// ACTIONS
		std::string keyString = keyToString(gameState);
		if (gameState->middleInputState.equlabInput.ctrlHeld && keyString != "") {
			middle::Id intersectedBubble;
			auto intersectingBubbleIt = intersectableBubbleCache->begin<components::IntersectingTag>();
			for (int i = 0; i < intersectableBubbleCache->getSize(); ++i) {
				auto intersecting = *intersectingBubbleIt;
				if (intersecting->intersectingTop) {
					intersectedBubble = intersectableBubbleCache->relevantIdVector[i];
					break;
				}
			}
			if (intersectedBubble.index != middle::UNASSIGNED) {
				auto action = std::make_shared<equlab::AddLabelCharacterToVariable>(intersectedBubble, keyString);
				bubble::queueEqulabAction(gameState, intersectedBubble, action);
			}
		}
		if (gameState->middleInputState.equlabInput.altHeld && keyString != "") {
			middle::Id intersectedBubble;
			auto intersectingBubbleIt = intersectableBubbleCache->begin<components::IntersectingTag>();
			for (int i = 0; i < intersectableBubbleCache->getSize(); ++i) {
				auto intersecting = *intersectingBubbleIt;
				if (intersecting->intersectingTop) {
					intersectedBubble = intersectableBubbleCache->relevantIdVector[i];
					break;
				}
			}
			if (intersectedBubble.index != middle::UNASSIGNED) {
				auto action = std::make_shared<equlab::AddLabelToFunction>(intersectedBubble, keyString);
				bubble::queueEqulabAction(gameState, intersectedBubble, action);
			}
		}

		auto& in = gameState->middleInputState.equlabInput;
		bool clicked =
			in.oneClicked
			|| in.twoClicked
			|| in.threeClicked
			|| in.fourClicked
			|| in.fiveClicked
			|| in.sixClicked
			|| in.sevenClicked
			|| in.eightClicked
			|| in.nineClicked
			|| in.zeroClicked
			|| in.f1Clicked
			|| in.f2Clicked
			|| in.f3Clicked
			|| in.f4Clicked
			|| in.f5Clicked
			|| in.f6Clicked
			|| in.f7Clicked
			|| in.f8Clicked
			|| in.f9Clicked
			|| in.f10Clicked
			|| in.f11Clicked
			|| in.f12Clicked;

		// MOUSE CLICK ACTIONS
		if (clicked) {

			middle::Id intersectedBubble;
			auto intersectingBubbleIt = intersectableBubbleCache->begin<components::IntersectingTag>();
			for (int i = 0; i < intersectableBubbleCache->getSize(); ++i) {
				auto intersectable = *intersectingBubbleIt;
				if (intersectable->intersectingTop) {
					intersectedBubble = intersectableBubbleCache->relevantIdVector[i];
					break;
				}
			}

			middle::Id targetId;
			if (intersectedBubble.index != middle::UNASSIGNED) {
				targetId = intersectedBubble;
			}

			bool cantAdd = false;
			if (intersectedBubble.index != middle::UNASSIGNED) {
				auto& intersectedShape = middle::getShape(gameState, intersectedBubble.index);
				auto unitComp = middle::getComponent<components::BubbleUnit>(intersectedShape);
				auto varComp = middle::getComponent<components::BubbleVariable>(intersectedShape);
				cantAdd = unitComp || varComp;
			}


			midMath::Vector3& mousePos = gameState->mouseState.mouseXZ_PlanePos;

			if (!cantAdd && in.oneClicked) {
				auto action = std::make_shared<equlab::AddBubble>(intersectedBubble, mousePos);
				bubble::queueEqulabAction(gameState, intersectedBubble, action);
			}
			else if (!cantAdd && in.twoClicked && intersectedBubble.index != middle::UNASSIGNED) {
				auto action = std::make_shared<equlab::AddUnit>(intersectedBubble, mousePos);
				bubble::queueEqulabAction(gameState, intersectedBubble, action);
			}
			else if (!cantAdd && in.threeClicked) {
				auto action = std::make_shared<equlab::AddEquals>(targetId, mousePos);
				bubble::queueEqulabAction(gameState, targetId, action);
			}
			else if (in.fourClicked) {
				auto action = std::make_shared<equlab::Negate>(targetId);
				bubble::queueEqulabAction(gameState, targetId, action);
			}
			else if (in.fiveClicked && intersectedBubble.index != middle::UNASSIGNED) {
				auto action = std::make_shared<equlab::Invert>(intersectedBubble);
				bubble::queueEqulabAction(gameState, intersectedBubble, action);
			}
			else if (in.sixClicked) {
				auto action = std::make_shared<equlab::Delete>(targetId);
				bubble::queueEqulabAction(gameState, targetId, action);
			}
			else if (in.sevenClicked) {
				auto action = std::make_shared<equlab::ToggleEditable>(targetId);
				bubble::queueEqulabAction(gameState, targetId, action);
			}
			else if (in.nineClicked) {
				auto action = std::make_shared<equlab::AddMultiplication>(targetId, mousePos);
				bubble::queueEqulabAction(gameState, targetId, action);
			}
			else if (in.eightClicked) {
				auto action = std::make_shared<equlab::AddPower>(targetId, mousePos);
				bubble::queueEqulabAction(gameState, targetId, action);
			}
			else if (in.f1Clicked) {
				auto action = std::make_shared<equlab::AddSwapBubble>(targetId, mousePos);
				bubble::queueEqulabAction(gameState, targetId, action);
			}
			else if (in.f2Clicked) {
				auto action = std::make_shared<equlab::AddLogicBubble>(targetId, mousePos);
				bubble::queueEqulabAction(gameState, targetId, action);
			}
			else if (in.f3Clicked) {
				auto action = std::make_shared<equlab::AddGateBubble>(targetId, mousePos, components::BubbleGateStatus::CLOSED);
				bubble::queueEqulabAction(gameState, targetId, action);
			}
			else if (in.f4Clicked) {
				auto action = std::make_shared<equlab::ToggleLogicBubbleStatus>(targetId);
				bubble::queueEqulabAction(gameState, targetId, action);
			}
			// indequalties
			else if (in.f5Clicked) {
				auto action = std::make_shared<equlab::AddInequals>(targetId, mousePos, false);
				bubble::queueEqulabAction(gameState, targetId, action);
			}
			// summation
			else if (in.f6Clicked) {
				auto action = std::make_shared<equlab::AddSummation>(targetId, mousePos);
				bubble::queueEqulabAction(gameState, targetId, action);
			}
		}
	}
};

static middle::SystemRegistrar<EqulabSystem> reg("EqulabSystem");
