#pragma once
#include "game_state.h"
#include "middle_system_registrar.h"
#include "MidComp/MouseIntersectable.h"
#include "middle_shape_utils.h"
#include "MidComp/MouseGrabbable.h"
#include "MidComp/GlobalTransform.h"
#include "MidComp/PlacementComponent.h"
#include "MidComp/LoopSociety.h"
#include "editor_actions.h"
#include "MidComp/GridElement.h"
#include "component_utils.h"
#include "MidComp/MouseSelectable.h"

namespace MouseGrabbingSystem {

	class MouseGrabbingSystem : public middle::MiddleGameplaySystem {
	public:
		MouseGrabbingSystem() {
			systemUpdateType = middle::SystemUpdateType::PREFRAME;
			systemModeType = middle::SystemModeType::EDITOR;
		}

		components::CompCache* grabbableCache;
		components::CompCache* placableCache;


		void init(middle::GameState* gameState) {
			grabbableCache = middle::newCompCache(gameState, systemName);
			grabbableCache->addType<components::MouseGrabbable>();
			grabbableCache->addType<components::GlobalTransform>();
			grabbableCache->addType<components::MouseSelectable>();
			placableCache = middle::newCompCache(gameState, systemName);
			placableCache->addType<components::PlacementComponent>();
			placableCache->addType<components::GlobalTransform>();
		}

		void dragging(middle::GameState* gameState, middle::MiddleMan& shape) {
			midMath::Vector3 pos = middle::getGlobalPosition(gameState, shape.id);
			auto grid = middle::getComponent<components::GridElement>(shape);

			auto& input = gameState->middleInputState.editorInput;

			if (!grid) {
				midMath::Vector3 cameraPos = gameState->editorState.camera.position;
				float objYDistance = std::abs(pos.y - cameraPos.y);
				float yDistance = std::abs(cameraPos.y);
				if (yDistance == 0)
					yDistance = 0.001f;
				midMath::Vector3 xzVel = midMath::Vector3Scale(gameState->mouseState.mouseXZ_PlaneVelocity * gameState->middleInputState.frameTime, objYDistance / yDistance);
				middle::moveShape(gameState, shape.id.index, xzVel);
			}
			else {
				midMath::Vector3 targetPos = gameState->mouseState.mouseXZ_PlanePos;
				middle::moveShape(gameState, shape.id.index, targetPos - pos);
			}
		}

		void releasing(middle::GameState* gameState) {
			// update move action with new positions for redo to work
			middle::EditorActionMove* lastMoveAction = nullptr;
			// find last move action
			for (int i = gameState->editorState.actionHistory.size() - 1; i >= 0; --i) {
				middle::EditorActionContainer* lastAction = gameState->editorState.actionHistory[i].get();
				lastMoveAction = dynamic_cast<middle::EditorActionMove*>(lastAction);
				if (lastMoveAction != nullptr) {
					break;
				}
			}
			assert(lastMoveAction);
			lastMoveAction->newPositions.resize(lastMoveAction->selectedShapes.size());
			for (int j = 0; j < lastMoveAction->selectedShapes.size(); ++j) {
				auto& selectedShape = middle::getShape(gameState, lastMoveAction->selectedShapes[j]);
				auto transform = middle::getComponent<components::GlobalTransform>(selectedShape);
				lastMoveAction->newPositions[j] = transform->pos;
			}
			gameState->editorState.grabbing = false;
		}

		void update(middle::GameState* gameState) override {
			auto& input = gameState->middleInputState.editorInput;

			// setup editor action for movement
			if (gameState->editorState.selectCount > 0 && gameState->middleInputState.editorInput.grabDown && !gameState->editorState.grabbing) {
				middle::queueEditorAction(gameState, std::make_shared<middle::EditorActionMove>(middle::getSelectedShapes(gameState)));
				gameState->editorState.grabbing = true;
				return;
			}

			auto grabbableIt = grabbableCache->begin<components::MouseGrabbable>();
			auto selectableIt = grabbableCache->begin<components::MouseSelectable>();
			for (int i = 0; i < grabbableCache->getSize(); ++i) {
				auto& shape = middle::getShape(gameState, grabbableCache->relevantIdVector[i].index);
				auto grabbable = *grabbableIt;
				auto selectable = *selectableIt;

				if (grabbable && selectable->selected && input.grabDown) {
					grabbable->grabbing = true;
				}
				else if (grabbable && !input.grabDown) {
					grabbable->grabbing = false;
				}

				if (grabbable->grabbing) {
					dragging(gameState, shape);
				}
			}

			auto placableIt = placableCache->begin<components::PlacementComponent>();
			for (int i = 0; i < placableCache->getSize(); ++i) {
				auto placable = *placableIt;
				auto& shape = middle::getShape(gameState, placableCache->relevantIdVector[i].index);
				if (input.mouseClicked) {
					middle::queueComponentDeletion<components::PlacementComponent>(gameState, shape.id);
					std::vector<middle::Id>members;
					middle::getAllChildren(gameState, shape.id, members);
					for (middle::Id& childId : members) {
						middle::MiddleMan& child = middle::getShape(gameState, childId.index);
						middle::queueComponentDeletion<components::PlacementComponent>(gameState, childId);
					}
				}

				if (placable->grabbing) {
					dragging(gameState, shape);
				}
			}

			if (input.grabReleased && gameState->editorState.grabbing) {
				releasing(gameState);
			}

		}
	};

	static middle::SystemRegistrar<MouseGrabbingSystem> reg("MouseGrabbingSystem");

}
