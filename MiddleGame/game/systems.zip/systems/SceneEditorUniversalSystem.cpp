#pragma once
#include "game_state.h"
#include "middle_system_registrar.h"
#include "MidComp/ActiveSceneEditableTag.h"
#include "component_utils.h"

class SceneEditorUniversalSystem : public middle::MiddleGameplaySystem {
	components::CompCache* activeObjectCache;

	void init(middle::GameState* gameState) override {
		activeObjectCache = middle::newCompCache(gameState, systemName);
		activeObjectCache->addType<components::ActiveSceneSelectableTag>();
	}
	void update(middle::GameState* gameState) override {
		//auto ui = [gameState, this]() {
		//	//ImGui::Begin("Universal editor");
		//	//if (ImGui::Button("Delete active")) {
		//	//	for (middle::Id activeId : activeObjectCache->relevantIdVector) {
		//	//		auto deleteAction = std::make_shared<middle::EditorActionDeleteSingle>(activeId);
		//	//		middle::queueAction(gameState, deleteAction);
		//	//		gameState->bubbleAlgebraState.bubbleActions.push_back(deleteAction);
		//	//	}
		//	//}
		//	//ImGui::End();
		//	};
		//middle::queueUi(gameState, ui);

	}
};

static middle::SystemRegistrar<SceneEditorUniversalSystem> reg("SceneEditorUniversalSystem");
